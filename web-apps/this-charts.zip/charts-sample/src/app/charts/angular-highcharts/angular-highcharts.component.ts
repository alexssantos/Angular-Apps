import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-angular-highcharts',
  templateUrl: './angular-highcharts.component.html',
  styleUrls: ['./angular-highcharts.component.css']
})
export class AngularHighchartsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
